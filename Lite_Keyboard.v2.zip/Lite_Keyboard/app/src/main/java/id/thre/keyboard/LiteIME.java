package id.thre.keyboard;


import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.inputmethodservice.*;
import android.inputmethodservice.KeyboardView.*;
import android.media.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.*;
import java.util.*;

public class LiteIME extends InputMethodService
implements OnKeyboardActionListener
{
	private boolean kMaterialOn = false;
	private boolean kQuertyOn = false;
	private boolean kSymbolsOn = false;
	private boolean capsLock;
    private long mLastShiftTime;
	private boolean kFontDefault = false;
	private boolean kFontBlack = false;
	private boolean kFontRed = false;
	private boolean kFontBlue = false;
	
	private KeyboardView kv;
	private KeyboardView kv1;
	private KeyboardView kv2;
	private KeyboardView kvBlue;
	private KeyboardView kvRed;
	private KeyboardView kvBlack;

	private Keyboard kQuertyCurrent;
	private Keyboard kQuerty;
	private Keyboard kQuerty123;
	private Keyboard kSymbolsCurrent;
	private Keyboard kSymbols;
	private Keyboard kSymbols_shift;
	private Keyboard kPref_Home;
	
	
	private static boolean IS_THRE = false;

	public static final int qwerty = R.xml.qwerty;
	public static final int qwerty123 = R.xml.qwerty123;
	public static final int symbols = R.xml.symbols;
	public static final int symbols_shift = R.xml.symbols_shift;
	public static final int pref_home = R.xml.pref_home;

	
	private String kBg = "#242424";

	
	@Override
	public View onCreateInputView()
	{
		kv1 = (KeyboardView)getLayoutInflater().inflate(R.layout.input_rf, null);
		kv2 = (KeyboardView)getLayoutInflater().inflate(R.layout.input, null);
		kvBlack = (KeyboardView)getLayoutInflater().inflate(R.layout.input_rb, null);
		kvRed = (KeyboardView)getLayoutInflater().inflate(R.layout.input_rr, null);
		kvBlue = (KeyboardView)getLayoutInflater().inflate(R.layout.input_rc, null);
		kQuerty = new Keyboard(this, R.xml.qwerty);
		kQuertyCurrent = kQuerty;
		
		if (kMaterialOn)
		{   kv = kv1; //Default Settings
			if (kFontDefault)
			{kv = kv1;}
			if (kFontRed)
			{kv = kvRed;}
			if (kFontBlack)
			{kv = kvBlack;}
			if (kFontBlue)
			{kv = kvBlue;}
			kv.setBackgroundColor(Color.parseColor(kBg));
		}
		else
		{kv = kv2;}
		
		if (kQuertyOn)
		{setKeyboard(kQuerty123, qwerty123);}
		else
		{setKeyboard(kQuerty, qwerty);}

		this.setThREOff();
		kSymbols = new Keyboard(this, R.xml.symbols);
		kSymbols_shift = new Keyboard(this, R.xml.symbols_shift);
		//kv.setBackgroundColor(Color.parseColor("#242424"));
		
		kv.setOnKeyboardActionListener(this);
		return kv;
	}

	private void setKeyboard(Keyboard keyboard, int xml)
	{
		keyboard = new Keyboard(this, xml);
		kQuertyCurrent = keyboard;
		kv.setKeyboard(keyboard);
		this.setIsThRE(false);
		voidKeyLabelOnCtrlOn();
		kv.invalidateAllKeys();
	}
	private void setSymbols(Keyboard symbols, int xml)
	{
		symbols = new Keyboard(this, xml);
		kSymbolsCurrent = symbols;
		kv.setKeyboard(symbols);
		this.setIsThRE(false);
		voidKeyLabelOnCtrlOn();
		kv.invalidateAllKeys();
	}


	@Override
	public void onPress(int p1)
	{
		// TODO: Implement  this method
	}

	@Override
	public void onRelease(int p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void onKey(int p1, int[] p2)
	{
		playClick(p1);
		InputConnection ic = getCurrentInputConnection();

		switch (p1)
		{
			case -500:
				kBg = "#00242424"; 
				kv.draw(new Canvas());
				//setInputView(onCreateInputView());
				break;
			case -501:
				kBg = "#242424"; 
				kv.draw(new Canvas());
				//setInputView(onCreateInputView());
				break;
			case -502:
				kBg = "#424242"; 
				kv.draw(new Canvas());
				//setInputView(onCreateInputView());
				break;
			case -503:
				kBg = "#99242424";
				kv.draw(new Canvas());
				//setInputView(onCreateInputView());
				break;
			case -609:
				kMaterialOn = !kMaterialOn;
				voidKeyLabelOnMaterialOn();
				break;
			case -600:
				setInputView(onCreateInputView());
				break;
			case -601:
				kFontDefault = true;
				kFontRed = false;
				kFontBlack = false;
				kFontBlue = false;
				//voidKeyLabel();
				//setInputView(onCreateInputView());
				break;
			case -602:
				kFontDefault = false;
				kFontRed = true;
				kFontBlack = false;
				kFontBlue = false;
				//voidKeyLabel();
				//setInputView(onCreateInputView());
				break;
			case -603:
				kFontDefault = false;
				kFontRed = false;
				kFontBlack = true;
				kFontBlue = false;
				//voidKeyLabel();
				//setInputView(onCreateInputView());
				break;
			case -604:
				kFontDefault = false;
				kFontRed = false;
				kFontBlack = false;
				kFontBlue = true;
				//voidKeyLabel();
				//setInputView(onCreateInputView());
				break;
			
			case -220:
				kv.setKeyboard(kQuertyCurrent);
				break;
			case -221:
				kv.setKeyboard(kQuertyCurrent);
				break;
			case -224:
				if (this.isThRE() && kv.isShifted())
				{
					setSymbols(kPref_Home, pref_home);
					voidKeyLabelOnMaterialOn();
					//voidKeyLabel();
				}
				else
				{
					kSymbolsCurrent = kSymbols;
					kv.setKeyboard(kSymbolsCurrent);

				}
				voidKeyLabelOnCtrlOn();
				break;
			case -228:
				kSymbolsOn = !kSymbolsOn;
				kSymbolsCurrent = kSymbols_shift;
				kv.setKeyboard(kSymbolsCurrent);
				voidKeyLabelOnCtrlOn();
				break;
			
			case -230:       
				if (this.isThRE())
				{
                    this.setThREOff();
                }
				else
				{
                    this.setThREOn();
                }
				voidKeyLabelOnCtrlOn();
				break;			
			case -254:
				Arrows(KeyEvent.KEYCODE_DPAD_LEFT);
				break;		
			case -256:
				Arrows(KeyEvent.KEYCODE_DPAD_RIGHT);
				break;		
			case -121373:			
				kMaterialOn = false;
				kBg = "#242424"; 
				kv.draw(new Canvas());
				kFontDefault = true;
				kFontRed = false;
				kFontBlack = false;
				kFontBlue = false;
				setInputView(onCreateInputView());
				break;
			case Keyboard.EDGE_BOTTOM://8
				break;
			case Keyboard.EDGE_RIGHT://2
				break;
			case Keyboard.EDGE_LEFT://1
				break;
			case Keyboard.EDGE_TOP://4
				break;
			case Keyboard.KEYCODE_CANCEL://-3
				break;
			case Keyboard.KEYCODE_MODE_CHANGE://-2
				break;
			case Keyboard.KEYCODE_DELETE ://-5
				handleBackspace();
				break;			
			case Keyboard.KEYCODE_SHIFT://-1
				handleCapsLock();
				break;
			case Keyboard.KEYCODE_ALT://-6
				break;
			case 46:
				if (this.isThRE())
				{
					kMaterialOn = !kMaterialOn;
					setInputView(onCreateInputView());
				}
				else
				{
					keyDownUp(KeyEvent.KEYCODE_PERIOD);
				}

				break;
			case Keyboard.KEYCODE_DONE://-4
				if (this.isThRE())
				{//Fn On
					kQuertyOn = !kQuertyOn;
					if (kQuertyOn)
					{   kQuerty123 = new Keyboard(this, R.xml.qwerty123);
						kQuertyCurrent = kQuerty123;
					}
					else
					{
						kQuerty = new Keyboard(this, R.xml.qwerty);
						kQuertyCurrent = kQuerty;
					}
					kv.setKeyboard(kQuertyCurrent);
					this.setIsThRE(false);
					voidKeyLabelOnCtrlOn();
				}//Fn On
				else
				{
					keyDownUp(KeyEvent.KEYCODE_ENTER);
				}
				break;			
			default:
				if (this.isThRE())
				{
					ctrlDownUp(p1);
				}
				else
				{
				    handleLetter(p1, ic);
				}

		}
	}




	public void handleLetter(int p1, InputConnection ic)
	{	//code for KEYCODE_SHIFT
		if (Character.isLetter((char)p1) && kv.isShifted())
		{
			char code = Character.toUpperCase((char)p1);
			ic.commitText(String.valueOf(code), 1);
			updateShiftKeyState(getCurrentInputEditorInfo());
		}
		else
		{
			char code = Character.toLowerCase((char)p1);
			ic.commitText(String.valueOf(code), 1);}
		kv.invalidateAllKeys();
	}


    private void updateShiftKeyState(EditorInfo attr)
	{
        if (attr != null && kv != null && kQuertyCurrent == kv.getKeyboard())
		{
            int caps = 0;
            EditorInfo ei = getCurrentInputEditorInfo();
            if (ei != null && ei.inputType != InputType.TYPE_NULL)
			{
                caps = getCurrentInputConnection().getCursorCapsMode(attr.inputType);
            }
            kv.setShifted(capsLock || caps != 0);
        }
    }
	private void handleCapsLock()
	{
        long now = System.currentTimeMillis();
        if (mLastShiftTime + 240 > now)
		{
            capsLock = !capsLock;
            mLastShiftTime = 0;
        }
		else
		{
            mLastShiftTime = now;
			capsLock = false;
        }
		kv.setShifted(capsLock || !kv.isShifted());
    }


	@Override
	public void onText(CharSequence p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeLeft()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeRight()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeDown()
	{
		// TODO: Implement this method
	}

	@Override
	public void swipeUp()
	{
		// TODO: Implement this method
	}

	public static boolean isThRE()
	{
        return IS_THRE;}
    public static void setIsThRE(boolean trueORfalse)
	{
        IS_THRE = trueORfalse;}
    public static void setThREOn()
	{
        IS_THRE = true;}
    public static void setThREOff()
	{
        IS_THRE = false;}



// untuk memudahkan keyEvent down / up
    private void keyDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyEventCode));
    }
	private void shiftDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON));
    }
	private void ctrlDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_CTRL_ON));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_CTRL_ON));
    }
	private void altDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_ALT_ON));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_ALT_ON));
    }
	private void ctrlAlt(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_CTRL_ON | KeyEvent.META_ALT_ON));
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_CTRL_ON | KeyEvent.META_ALT_ON));
    }
	private void shiftCtrlDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_CTRL_ON));
		getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_CTRL_ON));
    }
	private void shiftAltDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_ALT_ON));
		getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_ALT_ON));
    }
	private void shiftCtrlAltDownUp(int keyEventCode)
	{
        getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_DOWN, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_CTRL_ON | KeyEvent.META_ALT_ON));
		getCurrentInputConnection().sendKeyEvent(new KeyEvent(100, 100, KeyEvent.ACTION_UP, handleAZ(keyEventCode), 0, KeyEvent.META_SHIFT_ON | KeyEvent.META_CTRL_ON | KeyEvent.META_ALT_ON));
    }
	// menambahkan fungsi Arah untuk menandai text
	private void Arrows(int keyEventCode)
	{
		if (this.isThRE() && kv.isShifted())
		{
			shiftCtrlDownUp(keyEventCode);}
		else
		{
			if (this.isThRE())
			{
				shiftDownUp(keyEventCode);
			}
			else
			{
				keyDownUp(keyEventCode);
			}
		}

    }
	private void setKeyLabelOnCtrlOn(String setOldLabel, String setNewLabel)
	{
		int i;
		List<Keyboard.Key> keys = kv.getKeyboard().getKeys();
		for (i = 0; i < keys.size(); i++)
		{
			if (this.isThRE())
			{
				if (keys.get(i).label.equals(setOldLabel))
				{keys.get(i).label = setNewLabel;}}
			else
			{
				if (keys.get(i).label.equals(setNewLabel))
				{
					keys.get(i).label = setOldLabel;}
			}}
		kv.invalidateKey(i);}

	private void voidKeyLabelOnCtrlOn()
	{
		setKeyLabelOnCtrlOn("Beta", "𝔹𝕖𝕥𝕒");
		setKeyLabelOnCtrlOn("Abc", "𝔸𝕓𝕔");
		setKeyLabelOnCtrlOn("Sym", "𝕊𝕪𝕞");
		setKeyLabelOnCtrlOn("Del", "𝕗.𝔻𝕖𝕝");
		setKeyLabelOnCtrlOn("Fn", "𝔽ℕ");
		setKeyLabelOnCtrlOn("Enter", "𝔼𝕟𝕥𝕖𝕣");
		setKeyLabelOnCtrlOn("Shift", "𝕊𝕙𝕚𝕗𝕥");
		if (kMaterialOn)
		{
			setKeyLabelOnCtrlOn(".", "🅼");
		}
		else
		{
			setKeyLabelOnCtrlOn(".", "🄼");
		}
		kv.invalidateAllKeys();
	}
	private void setKeyLabelOnMaterialOn(String setOldLabel, String setNewLabel)
	{
		int i;
		List<Keyboard.Key> keys = kv.getKeyboard().getKeys();
		for (i = 0; i < keys.size(); i++)
		{
			if (kMaterialOn)
			{
				if (keys.get(i).label.equals(setOldLabel))
				{keys.get(i).label = setNewLabel;}}
			else
			{
				if (keys.get(i).label.equals(setNewLabel))
				{
					keys.get(i).label = setOldLabel;}
			}}
		kv.invalidateKey(i);}

	private void voidKeyLabelOnMaterialOn()
	{
		setKeyLabelOnMaterialOn("Background | Off", "Background | On");
		setKeyLabelOnMaterialOn("Font Color | Off", "Font Color | On");
		setKeyLabelOnMaterialOn("Del", "𝕗.𝔻𝕖𝕝");
		setKeyLabelOnMaterialOn("Fn", "𝔽ℕ");
		setKeyLabelOnMaterialOn("Enter", "𝔼𝕟𝕥𝕖𝕣");
		setKeyLabelOnMaterialOn("Shift", "𝕊𝕙𝕚𝕗𝕥");
		setKeyLabelOnMaterialOn("Basic", "Material");
		kv.invalidateAllKeys();
	}
	private void setKeyLabel(String setOldLabel, String setNewLabel, boolean trueOrfalse)
	{
		int i;
		List<Keyboard.Key> keys = kv.getKeyboard().getKeys();
		for (i = 0; i < keys.size(); i++)
		{
			if (trueOrfalse)
			{
				if (keys.get(i).label.equals(setOldLabel))
				{keys.get(i).label = setNewLabel;}}
			else
			{
				if (keys.get(i).label.equals(setNewLabel))
				{
					keys.get(i).label = setOldLabel;}
			}}
		kv.invalidateKey(i);}
	public void voidKeyLabel()
	{
		setKeyLabel("Black", "Current", kFontBlack);
		setKeyLabel("White", "White", kFontBlack);
		setKeyLabel("Red", "Red", kFontBlack);
		setKeyLabel("Blue", "Blue", kFontBlack);

		setKeyLabel("Black", "Black", kFontDefault);
		setKeyLabel("White", "Current", kFontDefault);
		setKeyLabel("Red", "Red", kFontDefault);
		setKeyLabel("Blue", "Blue", kFontDefault);

		setKeyLabel("Black", "Black", kFontRed);
		setKeyLabel("White", "White", kFontRed);
		setKeyLabel("Red", "Current", kFontRed);
		setKeyLabel("Blue", "Blue", kFontRed);
		
		setKeyLabel("Black", "Black", kFontBlue);
		setKeyLabel("White", "White", kFontBlue);
		setKeyLabel("Red", "Red", kFontBlue);
		setKeyLabel("Blue", "Current", kFontBlue);
		
	}
//berfungsi menghandle keyCode A-Z saat tombol Function diaktifkan
	private int handleAZ(int keycode)
	{
        char code = (char) keycode;
        switch (String.valueOf(code))
		{
            case "a":
                return KeyEvent.KEYCODE_A;
            case "b":
                return KeyEvent.KEYCODE_B;
            case "c":
                return KeyEvent.KEYCODE_C;
            case "d":
                return KeyEvent.KEYCODE_D;
            case "e":
                return KeyEvent.KEYCODE_E;
            case "f":
                return KeyEvent.KEYCODE_F;
            case "g":
                return KeyEvent.KEYCODE_G;
            case "h":
                return KeyEvent.KEYCODE_H;
            case "i":
                return KeyEvent.KEYCODE_I;
            case "j":
                return KeyEvent.KEYCODE_J;
            case "k":
                return KeyEvent.KEYCODE_K;
            case "l":
                return KeyEvent.KEYCODE_L;
            case "m":
                return KeyEvent.KEYCODE_M;
            case "n":
                return KeyEvent.KEYCODE_N;
            case "o":
                return KeyEvent.KEYCODE_O;
            case "p":
                return KeyEvent.KEYCODE_P;
            case "q":
                return KeyEvent.KEYCODE_Q;
            case "r":
                return KeyEvent.KEYCODE_R;
            case "s":
                return KeyEvent.KEYCODE_S;
            case "t":
                return KeyEvent.KEYCODE_T;
            case "u":
                return KeyEvent.KEYCODE_U;
            case "v":
                return KeyEvent.KEYCODE_V;
            case "w":
                return KeyEvent.KEYCODE_W;
            case "x":
                return KeyEvent.KEYCODE_X;
            case "y":
                return KeyEvent.KEYCODE_Y;
            case "z":
                return KeyEvent.KEYCODE_Z;
            default:
                return keycode;
        }}
	private void playClick(int keyCode)
	{
		AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
		switch (keyCode)
		{
			case 32: 
				am.playSoundEffect(AudioManager.FX_KEYPRESS_SPACEBAR);
				break;
			case Keyboard.KEYCODE_DONE:
			case 10:
				am.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN);
				break;
			case Keyboard.KEYCODE_SHIFT:
			case Keyboard.KEYCODE_MODE_CHANGE:			
			case Keyboard.KEYCODE_DELETE:
			case -220:
			case -221:
			case -224:
			case -228:
			case -230:
				am.playSoundEffect(AudioManager.FX_KEYPRESS_DELETE);
				break;		
			case -252:
			case -254:
			case -256:
			case -258:
				am.playSoundEffect(AudioManager.FX_FOCUS_NAVIGATION_UP);
				break;
			default: am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
		}		
	}

    private void handleBackspace()
	{
		if (this.isThRE())
		{
			keyDownUp(KeyEvent.KEYCODE_FORWARD_DEL);
		} 
		else
		{		
			keyDownUp(KeyEvent.KEYCODE_DEL);
			//updateShiftKeyState(getCurrentInputEditorInfo());
		}
    }

}


